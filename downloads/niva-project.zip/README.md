# NIVA / Brand identity + packaging

Self-initiated fictional concept. Prepared with AI assistance for Harsh Vardhan Tomar. No client affiliation or measured business outcomes.

## Brief
Create an approachable premium skincare concept for people overwhelmed by complicated routines. The visual system should feel calm, legible and coherent across a shelf, a feed and a small mobile screen.

## Audience hypothesis
Working adults looking for a simple daily routine. This is a target-audience hypothesis, not a finding from customer interviews.

## Delivered work
Identity board, three packaging form studies, 1080 × 1350 launch creative, editable SVG sources and PNG previews.

## Decisions
### One recognizable wordmark
A lowercase serif wordmark balances familiarity with a considered, premium tone. The full stop becomes a small recurring identity device.

### Muted shelf presence
Forest, sage and clay create a restrained hierarchy. Dark forest carries essential copy; lighter tones distinguish formats.

### A ritual, not a claim
Launch copy speaks about routine and simplicity. It avoids clinical efficacy claims that cannot be substantiated.

### Packaging hierarchy
Brand first, ritual name second, format last. The visual mockups test hierarchy; regulatory copy, dielines and supplier specifications remain production tasks.

## Review
Contrast review: clay labels and forest caps separate the packaging from the sage background. Large ritual naming supports recognition when the artwork is viewed as a thumbnail. Consumer readability testing remains proposed.

## Tools
Original SVG shapes and editable text, Python/Pillow for PNG export, HTML/CSS/JavaScript for the portfolio, ReportLab for PDF, FFmpeg for ZEST motion. No Figma or Adobe files are claimed.

## Run locally
Run `python3 -m http.server 8000` in this folder and open `http://localhost:8000/niva.html`. SVGs can be edited in Inkscape or imported into a vector editor. Font substitution may change layout; the PNGs preserve the exported appearance. Related-case-study and portfolio-PDF navigation needs the complete portfolio bundle.

## Online
https://harsh-visual-design-portfolio.steadywasp8.chatgpt.site/niva.html

## Production boundaries
Artwork is illustrative, not production packaging. Research and testing recommendations are proposals. No product, efficacy, sustainability or nutrition claims are substantiated.
