# ZEST / Social strategy + motion

Self-initiated fictional concept. Prepared with AI assistance for Harsh Vardhan Tomar. No client affiliation or measured business outcomes.

## Brief
Introduce a fictional snack brand through a modular launch campaign. Build recognition through repeated typography and color, then move from a familiar break-time problem toward product discovery.

## Audience hypothesis
Students and early-career adults encountering snack brands on mobile. Break-time relevance is a creative hypothesis requiring validation.

## Delivered work
Campaign identity board, three 1080 × 1350 creatives, one 1080 × 1920 story, nine-second MP4 reel, storyboard, two-week content plan and experiment brief.

## Decisions
### One campaign idea
Break the boring break gives each asset the same organizing idea while allowing different hooks.

### A three-stage sequence
The first creative establishes the 3 PM problem, the second introduces the brand idea, and the third invites discovery.

### A flexible visual grammar
Oversized type, three solid colors and one pack silhouette adapt to 4:5 feed and 9:16 story formats.

### Motion with reading time
The nine-second silent reel gives each of three messages three seconds. A gentle zoom supports movement without hiding the typography.

## Review
Placement review: short occasion-led hooks keep the campaign readable on mobile. The story variant places the CTA in a lower-middle safe area. Platform-specific overlays should be checked before paid placement.

## Tools
Original SVG shapes and editable text, Python/Pillow for PNG export, HTML/CSS/JavaScript for the portfolio, ReportLab for PDF, FFmpeg for ZEST motion. No Figma or Adobe files are claimed.

## Run locally
Run `python3 -m http.server 8000` in this folder and open `http://localhost:8000/zest.html`. SVGs can be edited in Inkscape or imported into a vector editor. Font substitution may change layout; the PNGs preserve the exported appearance. Related-case-study and portfolio-PDF navigation needs the complete portfolio bundle.

## Online
https://harsh-visual-design-portfolio.steadywasp8.chatgpt.site/zest.html

## Production boundaries
Artwork is illustrative, not production packaging. Research and testing recommendations are proposals. No product, efficacy, sustainability or nutrition claims are substantiated.
