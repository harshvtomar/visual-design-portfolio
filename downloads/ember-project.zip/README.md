# EMBER / Website design + development

Self-initiated fictional concept. Prepared with AI assistance for Harsh Vardhan Tomar. No client affiliation or measured business outcomes.

## Brief
Design a D2C coffee storefront that supports a quick first purchase. Clarify roast selection, show price and pack size near the action, and keep the shopping journey usable on mobile.

## Audience hypothesis
Home coffee drinkers comparing a small range of blends. All products, prices and tasting notes are illustrative prototype content.

## Delivered work
Identity board, product-range illustration, responsive storefront, roast filter and functional demo cart with quantity controls. No payments, orders or customer data.

## Decisions
### A clear entry point
A single hero action leads to the coffee range. The first screen communicates the category and the reason to explore.

### Choices before complexity
Three blends expose tasting notes, roast and pack size in parallel. Details stay close to the purchase action.

### Visible cart feedback
Adding an item updates the bag count and an announced status message. Quantity controls and removal allow recovery from mistakes.

### Accessible by default
Semantic buttons, explicit input labels, focus outlines and a reduced-motion rule support keyboard and assistive-technology use.

## Review
Hierarchy review: the implemented prototype gives the range its own anchor and keeps the bag accessible from the hero. Mobile cards stack into a single column. A future usability test should check roast comparison and cart recovery.

## Tools
Original SVG shapes and editable text, Python/Pillow for PNG export, HTML/CSS/JavaScript for the portfolio, ReportLab for PDF, FFmpeg for ZEST motion. No Figma or Adobe files are claimed.

## Run locally
Run `python3 -m http.server 8000` in this folder and open `http://localhost:8000/ember.html`. SVGs can be edited in Inkscape or imported into a vector editor. Font substitution may change layout; the PNGs preserve the exported appearance. Related-case-study and portfolio-PDF navigation needs the complete portfolio bundle.

## Online
https://harsh-visual-design-portfolio.steadywasp8.chatgpt.site/ember.html

## Production boundaries
Artwork is illustrative, not production packaging. Research and testing recommendations are proposals. No product, efficacy, sustainability or nutrition claims are substantiated.
